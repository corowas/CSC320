package CSC372.CTA1;

public class Main {
    public static void main(String[] args) {
        CheckingAccount b1 = new CheckingAccount();        
        b1.setName();
        b1.generateRandom();
        b1.accountSummary();
        b1.accountActions();
        b1.displayAccount();
    }
}
